<?php
namespace Acme\Sales\Exception;

/**
 * Cart Exception class
 *
 * @package Acme\Sales\Exception
 */
class CartException extends \Exception
{

}